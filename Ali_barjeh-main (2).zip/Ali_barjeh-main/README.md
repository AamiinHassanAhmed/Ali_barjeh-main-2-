# Ali_barjeh
full System Car Decoration Management System


## Requirments

* Visual Studio
* Sql Server 2014
* Crystal Report
* Divcomponent
